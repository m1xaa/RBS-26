# String formatting
subprocess.Popen('/bin/ls %s' % ('something',), shell=True)  # B602
subprocess.Popen('/bin/ls {}'.format('something'), shell=True)  # B602

# f-strings
user_input = "8.8.8.8; rm -rf /"
subprocess.call(f"ping {user_input}", shell=True)  # B602